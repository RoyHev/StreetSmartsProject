import React, { Component } from 'react'

class GroupIconButtons extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default GroupIconButtons
