import React, {Component} from 'react'
import { Container, Row, Col } from 'react-bootstrap';
import './footer.css';
import FooterSubMenu from './FooterSubMenu.js'
import FooterIcons from './FooterIcons.js'


class Footer extends Component{
    render(){
        return(
            <div align="center" className="wholefooter">
                <hr color="gray" width="100%" size="20"></hr>
                <div className="sub"><FooterIcons/></div>
                <div className="sub1">
                <FooterSubMenu/>
                </div>
                <div className="sub1">
                <FooterSubMenu/>
                </div>
            </div>

        );
    }
}

export default Footer;
