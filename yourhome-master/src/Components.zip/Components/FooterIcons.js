import React, {Component} from 'react'
import {TiSocialFacebook} from 'react-icons/ti';
import {MdLocalPhone} from 'react-icons/md';
import {IoIosMail} from 'react-icons/io';
import {FaRegSquare} from 'react-icons/fa'
import './footer.css'

class FooterIcon extends Component{
    render(){
        return(
            <div className="leftfooter">
                <FaRegSquare size="25"/>
                <div className="inbetween">
                <h6> something something</h6>
                </div>
                <div className="inbetween">
                <h6> something something</h6>
                </div>
                <div className="socialnets"><IoIosMail/></div>
                <div className="socialnets"><TiSocialFacebook/></div>
                <div className="socialnets"><MdLocalPhone/></div>
            </div>

        );
    }
}

export default FooterIcon;