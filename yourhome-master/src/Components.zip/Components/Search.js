import React from 'react'
// import {useHistory} from 'react-router-dom'
// import  from 'reactstrap';


import {Button,Navbar,Form,FormControl} from 'react-bootstrap';
class Search extends React.Component {
    render(){
        return (
            <div align="center">
            <Navbar bg="light" expand="lg">
  
  
  <Navbar.Collapse id="basic-navbar-nav">
   
    <Form inline>
      <FormControl type="text" placeholder="Search" className="mr-sm-2" />
      <Button variant="outline-success">Search</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>
</div>
        );
    }
}

export default Search;




