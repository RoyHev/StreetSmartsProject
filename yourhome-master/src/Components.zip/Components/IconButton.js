import React, { Component } from 'react'
import{FaTshirt} from 'react-icons/fa'
import{MdRestaurant} from 'react-icons/md'
import{FaBed} from 'react-icons/fa'
import{MdWork} from 'react-icons/md'
import{FaFirstAid} from 'react-icons/fa'
import { Button } from 'react-bootstrap'
import './iconButton.css'

class IconButton extends Component {

    clickHandler() {
        alert('ביגוד')
    }

    render() {
        const {buttonText,buttonColor} = this.props
        return (
            <div align="center" dir="rtl">
                <Button className="clothingStyle"> ביגוד {this.props.buttonText} 
                <FaTshirt></FaTshirt>
                </Button>
                <div class="spaces">
                <Button className="foodStyle"  onClick={this.clickHandler}>מזון {this.props.buttonText}
                <MdRestaurant></MdRestaurant>
                </Button>
                </div>

                <div class="spaces" backgroundColor="blue">
                <Button className="employStyle" onClick={this.clickHandler}>תעסוקה {this.props.buttonText}
                <MdWork></MdWork>
                </Button>
                </div>

                <div class="spaces">
                <Button onClick={this.clickHandler} className="lodgingStyle">לינה {this.props.buttonText} 
                <FaBed></FaBed>
                </Button>
                </div>

                <div class="spaces">
                <Button onClick={this.clickHandler} className="aidStyle">עזרה ראשונה {this.props.buttonText} 
                <FaFirstAid></FaFirstAid>
                </Button>
                </div>

            </div>
        )
    }
}

export default IconButton
