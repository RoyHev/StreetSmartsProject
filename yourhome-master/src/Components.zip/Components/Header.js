import React from 'react'
import logo from '../Images/logo192.png';

class Header extends React.Component{
    render(){
        return(
            <div align="center">
                <h2>Donate</h2>
                <img src={logo} alt="logo"></img>
            </div>
        )
    }
}

export default Header;