import {GiCircle} from 'react-icons/gi';
import './icons.css'
import React from 'react';
import GeneralButton from './GeneralButton.js';

class Icons extends React.Component {
  render() {
      return(
          <div class="icons-list" align="center">
              <h3 class="header1"> הכרה ברווחה כדר רחוב</h3>
              <p>
                <div class="text" align="Center"> 
                something something something something. </div> 
              </p>
              <p>
                <div  class="text" align="Center"> 
                something something something.
                </div> 
              </p>
              <p>
                <div  class="text" align="Center"> 
                something something something something.
                </div> 
              </p>
              <h4 class="header2"> למה כדאי להיות מוכר כדר רחוב</h4>
              <div class="item"><GiCircle size="25px"/></div>
              <div class="item"><GiCircle size="25px"/></div>
              <div class="item"><GiCircle size="25px"/></div>
              <div class="item"><GiCircle size="25px"/></div>
              <div class="button"> <GeneralButton name="התחל בתהליך!"></GeneralButton></div>
              <div className="line">
              <hr color="blue" width="100%" size="5"></hr>
              </div>
          </div>
      ); 
  }
}

export default Icons;