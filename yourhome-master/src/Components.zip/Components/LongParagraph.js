import React from 'react';
import {Alert} from 'react-bootstrap';


class LongParagraph extends React.Component {

    render(){
        return (
            <div>
            <Alert variant="success">
            <hr/>
        <div align="center">       
  <h1>מיצוי זכויות</h1>
  </div>  
  <p>
  <div align="Center"> 
 טקסט טקסט טקסט טקסט טקסט טקסט טקסט טקסט טקסט 
 </div> 
  </p>

  <p>
  <div align="Center"> 
 טקסט טקסט טקסט טקסט טקסט טקסט טקסט טקסט טקסט 
 </div> 
  </p>

  <p>
  <div align="Center"> 
 טקסט טקסט טקסט טקסט טקסט טקסט טקסט טקסט טקסט 
 </div> 
  </p>
  

 
</Alert>
            </div>
        );
    }
}

export default LongParagraph;
