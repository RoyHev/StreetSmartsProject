import React, {Component} from 'react'
import GeneralButton from './GeneralButton.js'
import './talk.css'

class TalkPanel extends Component{
    render(){
        return(
        <div className="divbg" align="Center">
            <h2 className="header"> אפשר גם לדבר </h2>
            <GeneralButton name="לרשימת מספרי מצוקה"></GeneralButton>
        </div>
        );
    }
}

export default TalkPanel;