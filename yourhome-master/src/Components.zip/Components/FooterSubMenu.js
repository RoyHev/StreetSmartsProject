import React, {Component} from 'react'
import './footer.css'

class FooterSubMenu extends Component{
    render(){
        return(
            <div align="right" className="container" >
                <div className="menu1">
                <div className="tmenu">
                    <h5> תפריט </h5>
                </div>
                <div className="rmenu">
                    <h6> link1 </h6>
                </div>
                <div className="rmenu">
                    <h6> link2 </h6>
                </div>
                <div className="rmenu">
                    <h6> link3 </h6>
                </div>
                </div>
                </div>
        );
    }

}

export default FooterSubMenu;