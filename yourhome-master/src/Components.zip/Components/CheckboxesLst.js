import React from 'react';
//import { WiredCheckbox } from '@bit/wiredjs.wired-elements.wired-checkbox';
import { WiredCheckbox } from "wired-checkbox";

class CheckboxesLst extends React.Component {
 
    render(){
        return (
            <div align="center">	
            	<h1>מה צריך</h1>
             <>מסמך א</>   <wired-checkbox align="center"> </wired-checkbox >
             <>מסמך ב</>   <wired-checkbox align="center"> </wired-checkbox >
             <>מסמך ג </>   <wired-checkbox align="center"> </wired-checkbox >
             <>מסמך ד </>   <wired-checkbox align="center"> </wired-checkbox >
            </div>
           
        );
    }
}

export default CheckboxesLst;